ИСПРАВЛЕНИЕ 02: NATIVE POLYLINEMASK WAS NOT CREATED

Скопируйте FUSION_GRAPH.lua из этого ZIP в
C:\Users\thoma\Downloads\chat gpt
с заменой старого FUSION_GRAPH.lua.

BUILD_PROJECT.lua после предыдущего исправления оставьте на месте.
Медиа, DATA.lua и шрифты не меняются.

В Resolve сохраните текущий проект, затем Console > Lua:

dofile([[C:\Users\thoma\Downloads\chat gpt\BUILD_PROJECT.lua]])

В начале сборки должна появиться строка Fusion graph builder revision 3.
Учитывается автоматическое переименование маски; при отказе импорта
рисунок строится из отдельных редактируемых RectangleMask/Transform/Merge.
Проверены синтаксис и логика обеих веток; реальный запуск проверяется в вашем Resolve.
