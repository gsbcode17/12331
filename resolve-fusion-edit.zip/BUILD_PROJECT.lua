-- Run INSIDE DaVinci Resolve: Workspace > Console > Lua.
-- Example: dofile([[C:\ResolveEdit\BUILD_PROJECT.lua]])
-- Creates a NEW uniquely named project. Never deletes or overwrites a project.
-- Revision 2: preserve default audio tracks; append dedicated stereo tracks.
local source = debug.getinfo(1, "S").source
assert(source:sub(1, 1) == "@", "Run this file with dofile(full_path)")
local root = source:sub(2):gsub("\\", "/"):match("^(.*)/[^/]+$") .. "/"
local data = dofile(root .. "DATA.lua")
local graph = dofile(root .. "FUSION_GRAPH.lua")
local stamp = os.date("%Y%m%d_%H%M%S")
local logFile = assert(io.open(root .. "output/build_" .. stamp .. ".log", "w"),
    "Cannot write the output directory. Extract the ENTIRE ZIP before running.")
local function log(s)
    local text = tostring(s)
    print("[Dental Fusion] " .. text)
    logFile:write(text .. "\n")
    logFile:flush()
end
local function exists(path)
    local f = io.open(path, "rb")
    if not f then return false end
    f:close()
    return true
end
local function ensure(ok, message)
    if not ok then error(message, 2) end
    return ok
end
local activeComp, undoStarted, locked
local function build()
    ensure(exists(root .. "media/source.mp4"), "Missing media/source.mp4")
    ensure(exists(root .. "media/speech.wav"), "Missing media/speech.wav")
    for _, cue in ipairs(data.sfx) do ensure(exists(root .. cue.path), "Missing " .. cue.path) end

    local app
    if type(Resolve) == "function" then app = Resolve() else app = rawget(_G, "resolve") end
    if not app and bmd and bmd.scriptapp then app = bmd.scriptapp("Resolve") end
    ensure(app, "Open DaVinci Resolve and run this in its Lua console")
    local pm = ensure(app:GetProjectManager(), "Project Manager unavailable")
    local version = "unknown"
    pcall(function() version = app:GetVersionString() end)
    log("Resolve " .. tostring(version))
    log("Bundle: " .. root)
    local name = "Dental_Edit_Fusion_" .. stamp
    local names = pm:GetProjectListInCurrentFolder() or {}
    local used = {}
    for _, n in pairs(names) do used[n] = true end
    local suffix = 1
    while used[name] do suffix = suffix + 1; name = "Dental_Edit_Fusion_" .. stamp .. "_" .. suffix end
    local project = ensure(pm:CreateProject(name), "Cannot create new project; save your open project and retry")
    log("Created new project: " .. name)
    ensure(project:SetSetting("timelineFrameRate", tostring(data.fps)), "Cannot set 25 fps")
    ensure(project:SetSetting("timelineResolutionWidth", tostring(data.width)), "Cannot set 1080 width")
    ensure(project:SetSetting("timelineResolutionHeight", tostring(data.height)), "Cannot set 1920 height")
    local pool = ensure(project:GetMediaPool(), "Media Pool unavailable")
    local function import(path)
        local result = pool:ImportMedia({root .. path})
        return ensure(result and result[1], "Media import failed: " .. path)
    end
    local video = import("media/source.mp4")
    local speech = import("media/speech.wav")
    local cueMedia = {}
    for _, cue in ipairs(data.sfx) do cueMedia[#cueMedia + 1] = import(cue.path) end
    local timeline = ensure(pool:CreateEmptyTimeline("DentalEdit_Fusion"), "Cannot create timeline")
    ensure(project:SetCurrentTimeline(timeline), "Cannot activate new timeline")
    ensure(timeline:SetStartTimecode("00:00:00:00"), "Cannot set timeline start timecode")
    local start = timeline:GetStartFrame()
    while timeline:GetTrackCount("video") < 1 do
        ensure(timeline:AddTrack("video"), "Cannot add source video track")
    end
    -- Resolve 21 can refuse to delete the default audio track. Keep it intact
    -- and append new stereo tracks without depending on the default preset.
    local function addStereoTrack(label)
        local before = timeline:GetTrackCount("audio")
        ensure(timeline:AddTrack("audio", "stereo"), "Cannot add stereo track: " .. label)
        local index = timeline:GetTrackCount("audio")
        ensure(index == before + 1, "Cannot identify the new audio track: " .. label)
        if not timeline:SetTrackName("audio", index, label) then
            log("WARNING: audio track rename failed: " .. label)
        end
        return index
    end
    local speechTrack = addStereoTrack("SPEECH")
    local sfxTrack = addStereoTrack("SOUND ACCENTS")
    local clips = pool:AppendToTimeline({{mediaPoolItem = video, startFrame = 0,
        endFrame = data.frames - 1, mediaType = 1, trackIndex = 1, recordFrame = start}})
    local clip = ensure(clips and clips[1], "Cannot append source video")
    local audio = pool:AppendToTimeline({{mediaPoolItem = speech, startFrame = 0,
        endFrame = data.frames - 1, mediaType = 2, trackIndex = speechTrack, recordFrame = start}})
    ensure(audio and audio[1], "Cannot append speech audio")
    for i, cue in ipairs(data.sfx) do
        local items = pool:AppendToTimeline({{mediaPoolItem = cueMedia[i], startFrame = 0,
            endFrame = cue.durationFrames - 1, mediaType = 2, trackIndex = sfxTrack,
            recordFrame = start + cue.startFrame}})
        ensure(items and items[1], "Cannot append sound effect " .. i)
    end
    if not timeline:SetTrackName("video", 1, "SOURCE + NATIVE FUSION") then log("WARNING: video track rename failed") end
    log("Timeline: video V1, speech A" .. speechTrack .. ", 7 sound effects A" .. sfxTrack)
    local compBefore = clip:GetFusionCompCount()
    activeComp = ensure(clip:AddFusionComp(), "AddFusionComp failed")
    local newCompIndex = clip:GetFusionCompCount()
    ensure(newCompIndex == compBefore + 1, "Cannot identify the newly added Fusion composition")
    activeComp:Lock(); locked = true
    activeComp:StartUndo("Build editable dental video"); undoStarted = true
    local font = "Arial"
    local fontList
    pcall(function() fontList = app:Fusion().FontManager:GetFontList() end)
    if type(fontList) == "table" and fontList[data.fontFamily] then font = data.fontFamily end
    if font ~= data.fontFamily then
        log("Noto Sans Display not installed: using editable Arial Bold fallback")
    end
    local summary = graph.build(activeComp, data, log, font)
    activeComp:EndUndo(true); undoStarted = false
    activeComp:Unlock(); locked = false
    local compNames = clip:GetFusionCompNameList() or {}
    local compName = ensure(compNames[newCompIndex], "Cannot identify the new Fusion composition name")
    ensure(clip:LoadFusionCompByName(compName), "Cannot activate the edited Fusion composition")
    ensure(pm:SaveProject(), "Project was created, but SaveProject failed")
    local compPath = root .. "output/" .. name .. ".comp"
    local okComp = clip:ExportFusionComp(compPath, newCompIndex)
    if okComp then log("Fusion composition: " .. compPath)
    else log("WARNING: .comp export failed; the node graph is still in the saved project") end
    local drpPath = root .. "output/" .. name .. ".drp"
    ensure(pm:ExportProject(name, drpPath, true), "Project is saved in Resolve, but .drp export failed")
    log("DRP project: " .. drpPath)
    log("Editable native tools: " .. summary.tools .. "; caption pages: " .. summary.pages)
    log("Done. Select the source video clip and open Fusion to edit the graph.")
    log("Keep the media folder: DRP and COMP files do not embed source video.")
    pcall(function() app:OpenPage("edit") end)
end

local ok, err = xpcall(build, debug.traceback)
if not ok then
    if activeComp then
        if undoStarted then pcall(function() activeComp:EndUndo(false) end) end
        if locked then pcall(function() activeComp:Unlock() end) end
    end
    log("BUILD FAILED: " .. tostring(err))
    log("No existing project was overwritten. Send this log for diagnosis.")
end
logFile:close()
if not ok then error(err, 0) end
