# Implementation references and validation scope

This package rebuilds the video using native Fusion tools through Resolve's
in-app Lua API. It is not a generated binary DRP file. The installed Resolve
application generates and exports the actual project on the user's machine.

- Bundled SDK mirror, modern API signature reference (updated May 7, 2025):
  https://raw.githubusercontent.com/minghe36/DaVinci-Resolve-Scripting-API-Documentation/master/doc.html
- Bundled Lua project/timeline example:
  https://raw.githubusercontent.com/deric/DaVinciResolve-API-Docs/main/examples/lua/1_sorted_timeline_from_folder.lua
- Bundled AddFusionComp example:
  https://raw.githubusercontent.com/deric/DaVinciResolve-API-Docs/main/examples/lua/2_compositions_from_timeline_clips.lua
- Native PolylineMask example:
  https://gitlab.com/WeSuckLess/Reactor/-/blob/master/Atoms/com.AndrewHazelden.TeapotMask/Macros/Mask/Teapot.setting
- Native settings parsing/pasting pattern:
  https://gitlab.com/WeSuckLess/Reactor/-/blob/master/Atoms/com.AsherRoland.AnimUtility/Scripts/Comp/FusionPixelStudio/Anim%20Utility/Open%20Anim%20Utility%20GUI.lua
- Native TextPlus/Transform template structure:
  https://gitlab.com/WeSuckLess/Reactor/-/blob/master/Atoms/com.FrameTools.CapCutCaptions/Templates/Edit/Titles/FrameTools/FT%20Bounce%20In%20TL.setting

These sources support the API/tool patterns; they do not establish testing in
Resolve 21. The relevant application version is not installed in the build
environment. Lua syntax, generated native-setting tables and API control flow
were checked headlessly, including global frame offsets, pre-existing clip
compositions, empty timeline tracks and error cleanup. No dummy DRP/COMP file
is shipped. All source media and fonts are included, with the font license.
