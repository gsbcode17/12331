-- Native Fusion graph builder. No rendered overlays or third-party OFX.
-- Run through BUILD_PROJECT.lua inside DaVinci Resolve's Lua console.
local M = {}

function M.build(comp, data, log, font)
    local W, H = data.width, data.height
    local attrs = comp:GetAttrs() or {}
    local first = tonumber(attrs.COMPN_GlobalStart) or 0
    local last = first + data.frames - 1
    local count, serial, keyCount = 0, 0, 0
    local ids = {}
    local function clampFrame(f)
        return first + math.max(0, math.min(data.frames - 1, math.floor(f + 0.5)))
    end
    local function requiredInput(tool, id)
        local list = tool:GetInputList() or {}
        for _, inp in pairs(list) do
            local a = inp:GetAttrs() or {}
            if a.INPS_ID == id then return inp end
        end
        error("Required Fusion input not found: " .. tostring(tool:GetAttrs().TOOLS_Name) .. "." .. id)
    end
    local function set(tool, id, value)
        requiredInput(tool, id)
        tool:SetInput(id, value)
    end
    local function connect(tool, id, source)
        requiredInput(tool, id)
        local output = source:FindMainOutput(1)
        assert(output, "Source has no main output")
        tool[id] = output
    end
    local function add(id, name)
        assert(not ids[name], "Duplicate node name: " .. name)
        ids[name] = true
        serial = serial + 1
        local t = assert(comp:AddTool(id, (serial % 5) * 150, math.floor(serial / 5) * 70), "Cannot create " .. id)
        t:SetAttrs({TOOLS_Name = name})
        count = count + 1
        return t
    end
    local function scalar(tool, id, keys)
        requiredInput(tool, id)
        local spline = assert(comp:BezierSpline({}), "Cannot create BezierSpline")
        tool[id] = spline
        local full = {}
        for _, k in ipairs(keys) do
            local frame = clampFrame(k[1])
            tool[id][frame] = k[2]
            full[frame] = {k[2], Flags = {Linear = true}}
            keyCount = keyCount + 1
        end
        -- Numeric assignment above is the documented legacy-compatible path.
        -- SetKeyFrames adds explicit linear interpolation when supported.
        pcall(function() spline:SetKeyFrames(full, true) end)
    end
    local function gate(tool, startFrame, endFrame, fade, initialAlpha)
        local d = math.max(1, math.min(fade or 5, math.floor((endFrame - startFrame) / 3)))
        local kv = {[0] = 0, [data.frames - 1] = 0}
        if startFrame > 0 then kv[startFrame - 1] = 0 end
        kv[startFrame] = initialAlpha or 0
        kv[startFrame + d] = 1
        kv[math.max(startFrame + d, endFrame - d)] = 1
        kv[endFrame] = 0
        local keys = {}
        for f, v in pairs(kv) do keys[#keys + 1] = {f, v} end
        table.sort(keys, function(a, b) return a[1] < b[1] end)
        scalar(tool, "Blend", keys)
    end
    local function merge(bg, fg, name)
        local t = add("Merge", name)
        connect(t, "Background", bg)
        connect(t, "Foreground", fg)
        return t
    end
    local function background(name, color)
        local t = add("Background", name)
        set(t, "Width", W)
        set(t, "Height", H)
        set(t, "TopLeftRed", color[1])
        set(t, "TopLeftGreen", color[2])
        set(t, "TopLeftBlue", color[3])
        set(t, "TopLeftAlpha", color[4] or 1)
        return t
    end
    local function rect(name, x, y, w, h, color, soft)
        local mask = add("RectangleMask", name .. "_Mask")
        set(mask, "Center", {x / W, 1 - y / H})
        set(mask, "Width", w / W)
        set(mask, "Height", h / H)
        if soft and soft > 0 then set(mask, "SoftEdge", soft) end
        local bg = background(name .. "_Color", color)
        connect(bg, "EffectMask", mask)
        return bg, mask
    end
    local function circle(name, x, y, radius, color)
        local mask = add("EllipseMask", name .. "_Mask")
        set(mask, "Center", {x / W, 1 - y / H})
        set(mask, "Width", radius * 2 / W)
        set(mask, "Height", radius * 2 / H)
        local bg = background(name .. "_Color", color)
        connect(bg, "EffectMask", mask)
        return bg
    end
    local function transform(input, name, x, y)
        local t = add("Transform", name)
        connect(t, "Input", input)
        local anchor = {x / W, 1 - y / H}
        set(t, "Pivot", anchor)
        set(t, "Center", anchor)
        return t
    end
    local function text(name, p)
        local t = add("TextPlus", name)
        set(t, "Width", W)
        set(t, "Height", H)
        set(t, "StyledText", p.text)
        set(t, "Font", font)
        set(t, "Style", "Bold")
        set(t, "Size", p.size * data.fontScale / W)
        set(t, "Center", {p.cx / W, 1 - p.cy / H})
        set(t, "HorizontalJustificationNew", 3)
        set(t, "VerticalJustificationNew", 3)
        set(t, "Red1", p.color[1])
        set(t, "Green1", p.color[2])
        set(t, "Blue1", p.color[3])
        set(t, "Alpha1", p.color[4] or 1)
        return t
    end
    local function polyline(name, points, stroke, color, closed)
        local maskName = name .. "_Mask"
        assert(not ids[maskName], "Duplicate mask name")
        ids[maskName] = true
        local function number(v) return (string.format("%.9f", v):gsub(",", ".")) end
        local entries = {}
        for _, p in ipairs(points) do
            entries[#entries + 1] = "{Linear=true,X=" .. number(p[1]/W-0.5) ..
                ",Y=" .. number(0.5-p[2]/H) .. ",LX=0,LY=0,RX=0,RY=0}"
        end
        local settings = "{Tools=ordered(){" .. maskName .. "=PolylineMask{Inputs={" ..
            "OutputSize=Input{Value=FuID{\"Custom\"}},MaskWidth=Input{Value=" .. W .. "}," ..
            "MaskHeight=Input{Value=" .. H .. "},PixelAspect=Input{Value={1,1}}," ..
            "Center=Input{Value={0.5,0.5}},Solid=Input{Value=0}," ..
            "BorderWidth=Input{Value=" .. number(stroke/W) .. "},SoftEdge=Input{Value=0}," ..
            "Polyline=Input{Value=Polyline{Closed=" .. tostring(closed or false) .. ",Points={" ..
            table.concat(entries, ",") .. "}}}}}}}"
        assert(bmd and bmd.readstring, "Fusion bmd.readstring is unavailable")
        local parsed = assert(bmd.readstring(settings), "Cannot parse native PolylineMask")
        comp:Paste(parsed)
        local mask = assert(comp:FindTool(maskName), "Native PolylineMask was not created")
        serial = serial + 1
        count = count + 1
        pcall(function() comp.CurrentFrame.FlowView:SetPos(mask, (serial%5)*150, math.floor(serial/5)*70) end)
        local bg = background(name .. "_Color", color)
        connect(bg, "EffectMask", mask)
        return bg
    end
    local function primitive(name, p)
        if p.kind == "text" then return text(name, p) end
        if p.kind == "rect" then return rect(name, p.cx, p.cy, p.w, p.h, p.color, p.soft) end
        if p.kind == "circle" then return circle(name, p.cx, p.cy, p.r, p.color) end
        if p.kind == "path" then return polyline(name, p.points, p.stroke or 4, p.color, p.closed) end
        if p.kind == "line" then
            return polyline(name, {{p.x1,p.y1},{p.x2,p.y2}}, p.stroke or 4, p.color, false)
        end
        error("Unknown primitive: " .. tostring(p.kind))
    end

    comp:SetPrefs({["Comp.FrameFormat.Width"] = W, ["Comp.FrameFormat.Height"] = H,
        ["Comp.FrameFormat.Rate"] = data.fps, ["Comp.FrameFormat.AspectX"] = 1,
        ["Comp.FrameFormat.AspectY"] = 1})
    local mediaIns = comp:GetToolList(false, "MediaIn") or {}
    local mediaOuts = comp:GetToolList(false, "MediaOut") or {}
    local mediaIn, mediaOut
    for _, t in pairs(mediaIns) do mediaIn = t; break end
    for _, t in pairs(mediaOuts) do mediaOut = t; break end
    assert(mediaIn and mediaOut, "Resolve did not create MediaIn/MediaOut for the source clip")
    local clear = background("Canvas_Transparent", {0, 0, 0, 0})
    local camera = transform(mediaIn, "CAMERA_Zoom_Keyframes", W * 0.54, H * 0.36)
    scalar(camera, "Size", data.zoom)
    local shade = rect("SHADE_Caption_Backdrop", W / 2, H * 0.88, W * 1.3, H * 0.42,
        {0.02, 0.07, 0.11, 0.56}, 0.15)
    local result = merge(camera, shade, "MERGE_Caption_Backdrop")

    log("Creating " .. #data.pages .. " editable caption pages")
    for _, page in ipairs(data.pages) do
        local prefix = string.format("CAP_%02d", page.index)
        local group = clear
        local size = page.fontSize
        local spacing = size * 1.17
        for i, line in ipairs(page.lines) do
            local y = 1598 + (i - (#page.lines + 1) / 2) * spacing
            local shadow = text(prefix .. "_Shadow_" .. i, {text = line.text, cx = 540,
                cy = y + 3, size = size, color = {0.015, 0.04, 0.06, 0.80}})
            group = merge(group, shadow, prefix .. "_ShadowMerge_" .. i)
            local color = line.accent and data.colors.teal or data.colors.white
            local foreground = text(prefix .. "_Text_" .. i, {text = line.text, cx = 540,
                cy = y, size = size, color = color})
            group = merge(group, foreground, prefix .. "_LineMerge_" .. i)
        end
        local motion = transform(group, prefix .. "_Entrance", 540, 1598)
        scalar(motion, "Size", {{0, 1}, {page.startFrame, 0.975},
            {page.startFrame + 6, 1}, {data.frames - 1, 1}})
        local pageMerge = merge(result, motion, prefix .. "_Visibility")
        gate(pageMerge, page.startFrame, page.endFrame, 2, 0.35)
        result = pageMerge
    end

    log("Creating " .. #data.scenes .. " native motion-graphics scenes")
    for _, scene in ipairs(data.scenes) do
        local group = clear
        for i, p in ipairs(scene.primitives) do
            local name = string.format("%s_%03d_%s", scene.id, i, p.label or p.kind)
            local fg = primitive(name, p)
            local m = merge(group, fg, name .. "_Merge")
            if p.reveal then
                local start = scene.startFrame + p.reveal
                scalar(m, "Blend", {{0, 0}, {start, 0}, {start + 4, 1}, {data.frames - 1, 1}})
            end
            group = m
        end
        local entrance = transform(group, scene.id .. "_Entrance", 540, 260)
        scalar(entrance, "Size", {{0, 1}, {scene.startFrame, 0.96},
            {scene.startFrame + 8, 1}, {data.frames - 1, 1}})
        local m = merge(result, entrance, scene.id .. "_Visibility")
        gate(m, scene.startFrame, scene.endFrame, 5)
        result = m
    end

    local track = rect("PROGRESS_Track", 540, 1766, 920, 3, {1, 1, 1, 0.22})
    result = merge(result, track, "PROGRESS_Track_Merge")
    local fill, fillMask = rect("PROGRESS_Fill", 80, 1766, 0.001, 3, data.colors.teal)
    scalar(fillMask, "Width", {{0, 0.001 / W}, {data.frames - 1, 920 / W}})
    fillMask.Center = comp:Path({})
    fillMask.Center[first] = {80 / W, 1 - 1766 / H, 0}
    fillMask.Center[last] = {540 / W, 1 - 1766 / H, 0}
    result = merge(result, fill, "PROGRESS_Fill_Merge")
    connect(mediaOut, "Input", result)
    log("Native graph complete: " .. count .. " tools, " .. keyCount .. " scalar key assignments")
    return {tools = count, keys = keyCount, pages = #data.pages, scenes = #data.scenes}
end

return M
