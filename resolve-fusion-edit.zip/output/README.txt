BUILD_PROJECT.lua creates the real DaVinci .drp and Fusion .comp files here,
using your installed DaVinci Resolve. No pre-generated or dummy project is included.
